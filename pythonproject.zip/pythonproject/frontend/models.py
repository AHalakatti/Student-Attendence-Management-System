from django.db import models
from django.contrib.auth.models import User


class Student(models.Model):
    name = models.CharField(max_length=35, null=True, blank=True)
    dob = models.DateField(null=True, blank=True)
    address = models.CharField(max_length=100, null=True, blank=True)
    RollNo = models.CharField(max_length=40,primary_key=True)
    country = models.CharField(max_length=35, null=True, blank=True)
    zipcode = models.CharField(max_length=20, null=True, blank=True)
      
    
class Attendance(models.Model):
    RollNo= models.ForeignKey('Student', on_delete=models.CASCADE, db_column='usn')
    current_attendance = models.IntegerField(null=False, default=0)
    percent = models.IntegerField(null=False, default=0)



