from django.shortcuts import render, HttpResponseRedirect
from django.contrib import messages
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render
from .models import *
from django.contrib import messages 

#Login
def Student_login(request):
    if not request.user.is_authenticated:
        if request.method == "POST":
            fmr = AuthenticationForm(request=request,data=request.POST)
            if fmr.is_valid():
                uname = fmr.cleaned_data['username']
                upass = fmr.cleaned_data['password']
                user = authenticate(username=uname, password=upass)
                if user is not None:
                    login(request,user)
                    messages.success(request,'Logged in successfully!!!')
                    return HttpResponseRedirect('/home/')
        else:
            fmr = AuthenticationForm()
        return render(request,'login.html',{'form':fmr})
    else:
        return HttpResponseRedirect('/home/')



# Creating an Employee
@login_required
@staff_member_required
def createStudent(request):
    if request.method == "POST":
        name = request.POST['name']
        address = request.POST['address']
        RollNo = request.POST['city']
        state = request.POST['state']
        zipcode = request.POST['zipcode']
        country = request.POST['country']
        post = request.POST['post']
        stu_obj = Student.objects.create(name=name,dob=dob,address=address,RollNo=RollNo,state=state,zipcode=zipcode,country=country,post=post)
        messages.success(request, "Student created successfully")
        return redirect('Student_list')
    return render(request, 'create_Student.html')
